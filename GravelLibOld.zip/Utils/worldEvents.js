// WorldEvents.js - Simulierte Welt-Events
import { world, system } from '@minecraft/server';

const WorldEvents = {
  _time: 0,
  _isRaining: false,
  _tick: 0,
  _onTimeChange: [],
  _onRainStart: [],
  _onRainStop: [],
  _onExplosion: [],
  _onLightning: [],

  /** Register time change callback */
  onTimeChange(callback) {
    this._onTimeChange.push(callback);
  },

  /** Register when rain starts */
  onRainStart(callback) {
    this._onRainStart.push(callback);
  },

  /** Register when rain ends */
  onRainStop(callback) {
    this._onRainStop.push(callback);
  },

  /** Register explosion (simulated) */
  onExplosion(callback) {
    this._onExplosion.push(callback);
  },

  /** Register lightning (simulated) */
  onLightning(callback) {
    this._onLightning.push(callback);
  },

  /** Run internal tick checker */
  init() {
    system.runInterval(() => {
      this._tick++;
      const time = world.getTimeOfDay();
      if (time !== this._time) {
        this._onTimeChange.forEach(cb => cb(time));
        this._time = time;
      }

      const rainingNow = world.getDimension("overworld").weather === "rain";
      if (rainingNow !== this._isRaining) {
        this._isRaining = rainingNow;
        if (rainingNow) this._onRainStart.forEach(cb => cb());
        else this._onRainStop.forEach(cb => cb());
      }
    }, 5);

    // Listen for explosions via sound workaround (if needed)
    world.afterEvents.explosion.subscribe(e => this._onExplosion.forEach(cb => cb(e)));
    world.afterEvents.weatherChange?.subscribe(e => {
      if (e.newWeather === "thunderstorm") this._onLightning.forEach(cb => cb(e));
    });
  }
};

WorldEvents.init();
export { WorldEvents };
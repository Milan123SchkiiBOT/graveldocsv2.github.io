// PlayerFeatures.js - Custom Player Enhancements
import { system, world } from '@minecraft/server';

export class PlayerFeatures {

  /** Freeze or unfreeze player movement */
  static freeze(player, enabled = true) {
    const command = `/inputpermission set @s movement ${enabled ? "disabled" : "enabled"}`;
    player.runCommandAsync(command);
  }

  /** Set player walk speed by teleporting forward manually */
  static setSpeed(player, multiplier = 1) {
    if (!player || multiplier <= 0) return;
    system.runInterval(() => {
      const vel = player.getVelocity();
      player.setVelocity({ x: vel.x * multiplier, y: vel.y, z: vel.z * multiplier });
    }, 1);
  }

  /** Send actionbar to player */
  static actionBar(player, text) {
    player.runCommandAsync(`titleraw @s actionbar {"rawtext":[{"text":"${text}"}]}`);
  }

  /** Force player to look in a direction */
  static lookAt(player, targetPos) {
    const pos = player.location;
    const dx = targetPos.x - pos.x;
    const dz = targetPos.z - pos.z;
    const yaw = Math.atan2(-dx, -dz) * (180 / Math.PI);
    player.teleport(pos, { rotation: { x: 0, y: yaw } });
  }

  /** Lock hotbar slot (auto-switches back if changed) */
  static lockSlot(player, index = 0) {
    system.runInterval(() => {
      if (player.selectedSlot !== index) {
        player.selectedSlot = index;
      }
    }, 1);
  }

  /** Fake title for effects */
  static fakeTitle(player, title = "", subtitle = "") {
    player.runCommandAsync(`titleraw @s title {"rawtext":[{"text":"${title}"}]}`);
    if (subtitle) {
      player.runCommandAsync(`titleraw @s subtitle {"rawtext":[{"text":"${subtitle}"}]}`);
    }
  }

  /** Add hearts (with absorption effect) */
  static addHealthBoost(player, value = 1) {
    const amplifier = Math.max(0, value - 1);
    player.addEffect("absorption", 999999, { amplifier });
  }
}

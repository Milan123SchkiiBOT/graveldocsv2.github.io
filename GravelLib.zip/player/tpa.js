// TPA.js - Teleport Request System
import { world, system } from '@minecraft/server';

const pendingTPA = new Map(); // key: target.name, value: { sender, timeout }
const tpaDisabled = new Set(); // player names who disabled tpa

export class TPA {
  static request(sender, target) {
    if (tpaDisabled.has(target.name)) {
      sender.sendMessage(`§c${target.name} has TPA disabled.`);
      return;
    }

    if (pendingTPA.has(target.name)) {
      sender.sendMessage(`§e${target.name} already has a pending request.`);
      return;
    }

    sender.sendMessage(`§aTPA request sent to §e${target.name}`);
    target.sendMessage(`§6${sender.name} §ehas requested to teleport to you.`);
    target.sendMessage(`§7Type §a/tpaccept §7to accept or §c/tpdeny §7to deny.`);

    const timeout = system.runTimeout(() => {
      if (pendingTPA.has(target.name)) {
        pendingTPA.delete(target.name);
        sender.sendMessage(`§cTPA request to ${target.name} expired.`);
      }
    }, 600); // 30 seconds

    pendingTPA.set(target.name, { sender, timeout });
  }

  static accept(target) {
    if (!pendingTPA.has(target.name)) {
      target.sendMessage(`§cNo pending TPA request.`);
      return;
    }

    const { sender, timeout } = pendingTPA.get(target.name);
    system.clearRun(timeout);
    pendingTPA.delete(target.name);

    sender.runCommandAsync(`tp @s ${target.location.x} ${target.location.y} ${target.location.z}`);
    sender.sendMessage(`§aTeleported to ${target.name}.`);
    target.sendMessage(`§aAccepted TPA request from ${sender.name}.`);
  }

  static deny(target) {
    if (!pendingTPA.has(target.name)) {
      target.sendMessage(`§cNo pending TPA request.`);
      return;
    }

    const { sender, timeout } = pendingTPA.get(target.name);
    system.clearRun(timeout);
    pendingTPA.delete(target.name);

    sender.sendMessage(`§c${target.name} denied your TPA request.`);
    target.sendMessage(`§cYou denied the TPA request from ${sender.name}.`);
  }

  static toggle(player, state) {
    if (state === true) {
      tpaDisabled.delete(player.name);
      player.sendMessage("§aTPA is now §aenabled.");
    } else {
      tpaDisabled.add(player.name);
      player.sendMessage("§cTPA is now §cdisabled.");
    }
  }

  static isDisabled(player) {
    return tpaDisabled.has(player.name);
  }
}

import { world , system , Player } from "@minecraft/server"
import { PlayerProperties } from "./player";
class AdvancedPlayer extends PlayerProperties {
    constructor(player) {
        super(player);
        this._permissions = new Map();
        this._initCustomFeatures();
    }

    // Permission System
    setPermission(permission, enabled = true) {
        this._permissions.set(permission, enabled);
        this._updateGameAbilities();
    }

    hasPermission(permission) {
        return this._permissions.get(permission) || false;
    }

    _updateGameAbilities() {
        // Fly-Permission
        if (this.hasPermission('fly')) {
            this.player.setGameMode('creative');
            this.player.sendMessage('Fly mode enabled by permission');
        }

        // Builder-Permission
        if (this.hasPermission('builder')) {
            this.player.addEffect('strength', 999999, { amplifier: 0, showParticles: false });
        }
    }

    // Custom Features
    _initCustomFeatures() {
        // Vanish System
        this._isVanished = false;
        
        // God Mode
        this._godMode = false;
        
        // NoClip
        this._noClip = false;
    }

    // Vanish System
    setVanish(state) {
        this._isVanished = state;
        this.player.setOnScreenDisplay('title', {
            title: state ? "§cVANISHED" : "",
            subtitle: "",
            fadeInDuration: 0,
            fadeOutDuration: 0,
            stayDuration: 99999
        });
        
        // Hide from other players
        for (const target of world.getPlayers()) {
            if (target.id !== this.player.id) {
                target.runCommandAsync(
                    state 
                    ? `effect @a[name="${this.player.name}"] invisibility 999999 0 true`
                    : `effect @a[name="${this.player.name}"] clear`
                );
            }
        }
    }

    toggleVanish() {
        this.setVanish(!this._isVanished);
    }

    // God Mode
    setGodMode(state) {
        this._godMode = state;
        this.player.getComponent('minecraft:health').setCurrent(state ? 999 : 20);
        this.player.sendMessage(`God mode ${state ? 'enabled' : 'disabled'}`);
    }

    // NoClip
    setNoClip(state) {
        this._noClip = state;
        this.player.runCommandAsync(`ability @s mayfly ${state}`);
        this.player.runCommandAsync(`ability @s noclip ${state}`);
        this.player.sendMessage(`NoClip ${state ? 'enabled' : 'disabled'}`);
    }

    // Teleport to Player
    teleportToPlayer(targetName) {
        const target = world.getPlayers().find(p => p.name === targetName);
        if (target) {
            const targetLoc = target.location;
            this.player.teleport(targetLoc);
            return true;
        }
        return false;
    }

    // Silent Command Execution
    silentCommand(command) {
        return this.player.runCommandAsync(`execute as @s at @s run ${command}`);
    }

    // Fake Op (Client-side)
    fakeOp() {
        this.player.sendMessage('§4§oOP: §r§7You are now op!');
        this.player.playSound('random.levelup');
    }
}

// Permission Manager
class PermissionManager {
    constructor() {
        this.groups = {
            admin: ['fly', 'builder', 'vanish', 'god', 'noclip'],
            moderator: ['fly', 'vanish'],
            vip: ['fly']
        };
    }

    setPlayerGroup(player, group) {
        const advPlayer = getPlayerProperties(player);
        
        // Clear all permissions first
        advPlayer._permissions.clear();
        
        // Add group permissions
        if (this.groups[group]) {
            this.groups[group].forEach(perm => {
                advPlayer.setPermission(perm);
            });
        }
        
        advPlayer._updateGameAbilities();
    }
}

// Beispielnutzung:
const permManager = new PermissionManager();

world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;
    const advPlayer = new AdvancedPlayer(player);
    
    // Admin-Rechte für OP-Player
    if (player.isOp()) {
        permManager.setPlayerGroup(player, 'admin');
    }
});

world.beforeEvents.chatSend.subscribe(event => {
    const [cmd, ...args] = event.message.split(' ');
    const player = event.sender;
    const advPlayer = getPlayerProperties(player);
    
    switch(cmd) {
        case '!vanish':
            advPlayer.toggleVanish();
            event.cancel = true;
            break;
            
        case '!god':
            advPlayer.setGodMode(!advPlayer._godMode);
            event.cancel = true;
            break;
            
        case '!tp':
            if (args[0] && advPlayer.hasPermission('tp')) {
                advPlayer.teleportToPlayer(args[0]);
                event.cancel = true;
            }
            break;
    }
});
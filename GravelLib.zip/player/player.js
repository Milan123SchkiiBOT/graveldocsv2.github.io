import { world, system, Player} from "@minecraft/server"

export class PlayerProperties {
  constructor(player) {
      this.player = player;
  }

  // Basic Properties
  get name() {
      return this.player.name;
  }

  get id() {
      return this.player.id;
  }

  get isSneaking() {
      return this.player.isSneaking;
  }

  get isSprinting() {
      return this.player.isSprinting;
  }

  get isFlying() {
      return this.player.isFlying;
  }

  get isSwimming() {
      return this.player.isSwimming;
  }

  get isGliding() {
      return this.player.isGliding;
  }

  get isInWater() {
      return this.player.isInWater;
  }

  get isOnGround() {
      return this.player.isOnGround;
  }

  // Position and Rotation
  get position() {
      return this.player.location;
  }

  get x() {
      return this.player.location.x;
  }

  get y() {
      return this.player.location.y;
  }

  get z() {
      return this.player.location.z;
  }

  get rotation() {
      return {
          pitch: this.player.getRotation().x,
          yaw: this.player.getRotation().y
      };
  }

  get pitch() {
      return this.player.getRotation().x;
  }

  get yaw() {
      return this.player.getRotation().y;
  }

  // Health and Effects
  get health() {
      return this.player.getComponent('minecraft:health').current;
  }

  get maxHealth() {
      return this.player.getComponent('minecraft:health').value;
  }

  get hunger() {
      return this.player.getComponent('minecraft:hunger').current;
  }

  get saturation() {
      return this.player.getComponent('minecraft:hunger').saturation;
  }

  get exhaustion() {
      return this.player.getComponent('minecraft:hunger').exhaustion;
  }

  get experience() {
      return this.player.getComponent('minecraft:experience').value;
  }

  get level() {
      return this.player.getComponent('minecraft:level').current;
  }

  // Inventory and Equipment
  get inventory() {
      return this.player.getComponent('minecraft:inventory').container;
  }

  get selectedSlot() {
      return this.player.selectedSlot;
  }

  get selectedItem() {
      return this.player.getComponent('minecraft:inventory').container.getItem(this.player.selectedSlot);
  }

  get armor() {
      const inv = this.player.getComponent('minecraft:inventory').container;
      return {
          head: inv.getItem(39),
          chest: inv.getItem(38),
          legs: inv.getItem(37),
          feet: inv.getItem(36)
      };
  }

  get offhandItem() {
      return this.player.getComponent('minecraft:inventory').container.getItem(40);
  }

  // Gameplay Stats
  get score() {
      return this.player.score;
  }

  get playTime() {
      return this.player.getDynamicProperty('playTime') || 0;
  }

  set playTime(value) {
      this.player.setDynamicProperty('playTime', value);
  }

  get lastDeathLocation() {
      return this.player.getDynamicProperty('lastDeathLocation') || null;
  }

  set lastDeathLocation(value) {
      this.player.setDynamicProperty('lastDeathLocation', value);
  }

  // Player State
  get gameMode() {
      return this.player.getGameMode();
  }

  get isOp() {
      return this.player.isOp();
  }

  get isMoving() {
      const vel = this.player.getVelocity();
      return vel.x !== 0 || vel.y !== 0 || vel.z !== 0;
  }

  get velocity() {
      return this.player.getVelocity();
  }

  // Custom Properties
  get customProperties() {
      return this.player.getDynamicProperty('customProps') || {};
  }

  setCustomProperty(key, value) {
      const props = this.customProperties;
      props[key] = value;
      this.player.setDynamicProperty('customProps', props);
  }

  getCustomProperty(key) {
      return this.customProperties[key];
  }

  // Utility Methods (als normale Methoden statt Getter)
  distanceTo(other) {
      const otherPos = other.location ? other.location : other;
      const dx = this.x - otherPos.x;
      const dy = this.y - otherPos.y;
      const dz = this.z - otherPos.z;
      return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  isLookingAt(position, maxAngle = 15) {
      const dir = {
          x: position.x - this.x,
          y: position.y - this.y,
          z: position.z - this.z
      };
      
      const length = Math.sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
      if (length === 0) return true;
      
      const normDir = {
          x: dir.x / length,
          y: dir.y / length,
          z: dir.z / length
      };
      
      const yawRad = this.yaw * (Math.PI / 180);
      const pitchRad = this.pitch * (Math.PI / 180);
      
      const playerDir = {
          x: -Math.sin(yawRad) * Math.cos(pitchRad),
          y: -Math.sin(pitchRad),
          z: Math.cos(yawRad) * Math.cos(pitchRad)
      };
      
      const dot = normDir.x * playerDir.x + normDir.y * playerDir.y + normDir.z * playerDir.z;
      const angle = Math.acos(dot) * (180 / Math.PI);
      
      return angle <= maxAngle;
  }

  // Action Methods
  sendMessage(message) {
      this.player.sendMessage(message);
  }

  playSound(soundId, soundOptions) {
      this.player.playSound(soundId, soundOptions);
  }

  teleport(location, dimension, rotation) {
      this.player.teleport(location, { dimension, rotation });
  }

  giveItem(item) {
      if (Array.isArray(item)) {
          return item.every(i => this.player.getComponent('minecraft:inventory').container.addItem(i));
      }
      return this.player.getComponent('minecraft:inventory').container.addItem(item);
  }

  clearInventory() {
      const inv = this.player.getComponent('minecraft:inventory').container;
      for (let i = 0; i < inv.size; i++) {
          inv.setItem(i, undefined);
      }
  }

  // Effect Management
  addEffect(effectType, duration, amplifier, showParticles) {
      this.player.addEffect(effectType, duration, { amplifier, showParticles });
  }

  removeEffect(effectType) {
      this.player.removeEffect(effectType);
  }

  hasEffect(effectType) {
      return this.player.getEffect(effectType) !== undefined;
  }

  getEffectAmplifier(effectType) {
      const effect = this.player.getEffect(effectType);
      return effect ? effect.amplifier : 0;
  }

  getEffectDuration(effectType) {
      const effect = this.player.getEffect(effectType);
      return effect ? effect.duration : 0;
  }

  // Advanced Methods
  getViewDirection() {
      const yawRad = this.yaw * (Math.PI / 180);
      const pitchRad = this.pitch * (Math.PI / 180);
      return {
          x: -Math.sin(yawRad) * Math.cos(pitchRad),
          y: -Math.sin(pitchRad),
          z: Math.cos(yawRad) * Math.cos(pitchRad)
      };
  }

  getBlockInSight(maxDistance = 10) {
      const start = this.position;
      const direction = this.getViewDirection();
      
      for (let i = 0; i < maxDistance; i += 0.2) {
          const checkPos = {
              x: start.x + direction.x * i,
              y: start.y + direction.y * i,
              z: start.z + direction.z * i
          };
          
          const block = this.player.dimension.getBlock(checkPos);
          if (block && block.typeId !== 'minecraft:air') {
              return block;
          }
      }
      
      return null;
  }

  getEntitiesInRange(radius) {
      return this.player.dimension.getEntities({
          location: this.position,
          maxDistance: radius,
          excludeTypes: ['minecraft:player']
      });
  }

  getPlayersInRange(radius) {
      return this.player.dimension.getPlayers({
          location: this.position,
          maxDistance: radius,
          exclude: [this.player]
      });
  }

    // Flight Properties
    get canFly() {
        return this.player.getDynamicProperty('flightEnabled') || false;
    }

    set canFly(value) {
        this.player.setDynamicProperty('flightEnabled', value);
        this.player.setGameMode(value ? 'creative' : 'survival');
    }

    get flightSpeed() {
        return this.player.getDynamicProperty('flightSpeed') || 0.05;
    }

    set flightSpeed(value) {
        this.player.setDynamicProperty('flightSpeed', Math.max(0.01, Math.min(1.0, value)));
    }

    // Flight Methods
    enableFlight(speed = 0.05) {
        this.canFly = true;
        this.flightSpeed = speed;
        this.player.sendMessage('Flight mode enabled!');
    }

    disableFlight() {
        this.canFly = false;
        this.player.sendMessage('Flight mode disabled');
    }

    toggleFlight() {
        if (this.canFly) {
            this.disableFlight();
        } else {
            this.enableFlight();
        }
    }

    setFlightSpeed(speed) {
        const newSpeed = Math.max(0.01, Math.min(1.0, speed));
        this.flightSpeed = newSpeed;
        this.player.sendMessage(`Flight speed set to ${newSpeed.toFixed(2)}`);
    }
}

// Utility function
export function getPlayerProperties(player) {
  if (!player.hasDynamicProperty('playerProps')) {
      player.setDynamicProperty('playerProps', new PlayerProperties(player));
  }
  return player.getDynamicProperty('playerProps');
}



/*
const registeredCommands = new Map();
let helpEnabled = false;
let showDescriptions = true;

export function commandBuilder(name, description = '') {
  const command = {
    name,
    description,
    _callback: null,
    _condition: () => true,
    run(callback) {
      this._callback = callback;
      return this;
    },
    if(conditionFn) {
      this._condition = conditionFn;
      return this;
    }
  };

  registeredCommands.set(name, command);
  return command;
}

commandBuilder.setHelp = function (showDesc = true, enabled = true) {
  showDescriptions = showDesc;
  helpEnabled = enabled;
};

world.beforeEvents.chatSend.subscribe(event => {
  const { sender, message } = event;
  if (!message.startsWith('!')) return;

  const args = message.slice(1).split(/\s+/);
  const cmd = args.shift().toLowerCase();

  if (cmd === 'help' && helpEnabled) {
    event.cancel = true;
    sender.sendMessage("§6§lAvailable Commands:");
    for (const [name, cmdData] of registeredCommands) {
      if (!cmdData._condition(sender)) continue;
      if (showDescriptions && cmdData.description) {
        sender.sendMessage(`§e!${name} §7- ${cmdData.description}`);
      } else {
        sender.sendMessage(`§e!${name}`);
      }
    }
    return;
  }

  if (registeredCommands.has(cmd)) {
    const data = registeredCommands.get(cmd);
    if (!data._condition(sender)) return;
    event.cancel = true;
    if (data._callback) data._callback(sender, args);
  } else {
    // Command not found response
    event.cancel = true;
    sender.sendMessage(`§cUnknown command: §f!${cmd}`);
  }
});*/
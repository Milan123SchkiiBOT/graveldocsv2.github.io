// PlayerEvents.js - Enhanced Player Event System
import { world, system, BlockPermutation } from '@minecraft/server';
import { PlayerFeatures } from './playerFeatures';

let player = null; // Global player reference (latest active)
let globalPlaceRule = { disabled: false, allowedList: [] };
let globalBreakRule = { disabled: false, allowedList: [] };
let globalRespawnBlock = null;
const protectedAreas = []; // area: { from: Vector3, to: Vector3, allowBreak: bool, allowPlace: bool }

function isAllowed(typeId, list) {
  if (!Array.isArray(list)) return false;
  return list.some(entry => {
    if (entry.endsWith("*")) {
      return typeId.startsWith(entry.replace("*", ""));
    }
    return typeId === entry;
  });
}

function isInArea(pos, area) {
  const min = {
    x: Math.min(area.from.x, area.to.x),
    y: Math.min(area.from.y, area.to.y),
    z: Math.min(area.from.z, area.to.z),
  };
  const max = {
    x: Math.max(area.from.x, area.to.x),
    y: Math.max(area.from.y, area.to.y),
    z: Math.max(area.from.z, area.to.z),
  };
  return (
    pos.x >= min.x && pos.x <= max.x &&
    pos.y >= min.y && pos.y <= max.y &&
    pos.z >= min.z && pos.z <= max.z
  );
}

export class PlayerEvents {

  static addArea(from, to, allowPlace = false, allowBreak = false) {
    protectedAreas.push({ from, to, allowPlace, allowBreak });
  }

  /** Triggered when a player joins the game */
  static onJoin(callback) {
    world.afterEvents.playerJoin.subscribe(event => {
      player = event.player;
      callback(event.player);
    });
  }

  /** Triggered when a player leaves the game */
  static onLeave(callback) {
    world.afterEvents.playerLeave.subscribe(event => callback(event.playerName));
  }

  /** Triggered when a player hits another entity */
  static onHit(callback) {
    world.afterEvents.entityHurt.subscribe(event => {
      if (event.damagingEntity.typeId === 'minecraft:player') {
        player = event.damagingEntity;
        callback(event.damagingEntity, event.hitEntity);
      }
    });
  }

  /** Triggered when a player interacts with a block */
  static onInteract(callback) {
    world.afterEvents.playerInteractWithBlock.subscribe(event => {
      player = event.player;
      callback(event.player, event.block);
    });
  }

  static setGlobalPlaceRule(disabled = false, allowedList = []) {
    globalPlaceRule = { disabled, allowedList };
  }

  static setGlobalBreakRule(disabled = false, allowedList = []) {
    globalBreakRule = { disabled, allowedList };
  }

  static setGlobalRespawnBlock(blockTypeId) {
    globalRespawnBlock = blockTypeId;
  }

  static _initBlockPlace() {
    world.beforeEvents.playerPlaceBlock.subscribe(event => {
      player = event.player;
      const itemType = event.itemStack?.typeId ?? "";
      const location = event.blockLocation;

      for (const area of protectedAreas) {
        if (isInArea(location, area) && !area.allowPlace) {
          event.cancel = true;
          event.player.sendMessage("§cYou can't place blocks in this area!");
          return;
        }
      }

      if (globalPlaceRule.disabled && !isAllowed(itemType, globalPlaceRule.allowedList)) {
        event.cancel = true;
        event.player.sendMessage(`§cYou are not allowed to place this block.`);
      }
    });
  }

  static _initBlockBreak() {
    world.beforeEvents.playerBreakBlock.subscribe(event => {
      player = event.player;
      const typeId = event.block.typeId;
      const location = event.block.location;

      for (const area of protectedAreas) {
        if (isInArea(location, area) && !area.allowBreak) {
          event.cancel = true;
          event.player.sendMessage("§cYou can't break blocks in this area!");
          return;
        }
      }

      if (globalBreakRule.disabled && !isAllowed(typeId, globalBreakRule.allowedList)) {
        event.cancel = true;
        event.player.sendMessage(`§cYou are not allowed to break this block.`);
        return;
      }

      if (globalRespawnBlock && typeId === globalRespawnBlock) {
        system.runTimeout(() => {
          const block = event.dimension.getBlock(event.block.location);
          block.setPermutation(BlockPermutation.resolve(typeId));
        }, 20);
      }
    });
  }

  static init() {
    this._initBlockPlace();
    this._initBlockBreak();
  }

  static knockBack(p, strength = 0.5, direction = { x: 0, y: 0.5, z: 0 }) {
    p.applyKnockback(direction.x, direction.z, strength, direction.y);
  }

  static onDeath(callback) {
    world.afterEvents.entityDie.subscribe(event => {
      if (event.deadEntity.typeId === 'minecraft:player') {
        player = event.deadEntity;
        callback(event.deadEntity);
      }
    });
  }

  static onRespawn(callback) {
    world.afterEvents.playerSpawn.subscribe(event => {
      player = event.player;
      callback(event.player);
    });
  }
}

PlayerEvents.init();

export { player };


const registeredCommands = new Map();
let helpEnabled = false;
let showDescriptions = true;

export function commandBuilder(name, description = '') {
  const command = {
    name,
    description,
    _callback: null,
    _condition: () => true,
    run(callback) {
      this._callback = callback;
      return this;
    },
    if(conditionFn) {
      this._condition = conditionFn;
      return this;
    }
  };

  registeredCommands.set(name, command);
  return command;
}

commandBuilder.setHelp = function (showDesc = true, enabled = true) {
  showDescriptions = showDesc;
  helpEnabled = enabled;
};

world.beforeEvents.chatSend.subscribe(event => {
  const { sender, message } = event;
  if (!message.startsWith('!')) return;

  const args = message.slice(1).split(/\s+/);
  const cmd = args.shift().toLowerCase();

  if (cmd === 'help' && helpEnabled) {
    event.cancel = true;
    sender.sendMessage("§6§lAvailable Commands:");
    for (const [name, cmdData] of registeredCommands) {
      if (!cmdData._condition(sender)) continue;
      if (showDescriptions && cmdData.description) {
        sender.sendMessage(`§e!${name} §7- ${cmdData.description}`);
      } else {
        sender.sendMessage(`§e!${name}`);
      }
    }
    return;
  }

  if (registeredCommands.has(cmd)) {
    const data = registeredCommands.get(cmd);
    if (!data._condition(sender)) return;
    event.cancel = true;
    if (data._callback) data._callback(sender, args);
  } else {
    // Command not found response
    event.cancel = true;
    sender.sendMessage(`§cUnknown command: §f!${cmd}`);
  }
});
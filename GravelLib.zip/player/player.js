// PlayerEvents.js - Enhanced Player Event System (player.onJoin, player.onMove via class)
import { world, system, BlockPermutation } from '@minecraft/server';
import { PlayerFeatures } from './playerFeatures';

let globalPlaceRule = { disabled: false, allowedList: [] };
let globalBreakRule = { disabled: false, allowedList: [] };
let globalRespawnBlock = null;
const protectedAreas = []; // area: { from: Vector3, to: Vector3, allowBreak: bool, allowPlace: bool }

const _lastPosMap = new Map();

export class Player {
  constructor(player) {
    this.player = player;
    this._onJoin = null;
    this._onMove = null;
  }

  onJoin(callback) {
    if (typeof callback === 'function') {
      this._onJoin = callback;
    }
  }

  onMove(callback) {
    if (typeof callback === 'function') {
      this._onMove = callback;
    }
  }

  get name() {
    return this.player.name;
  }

  get location() {
    return this.player.location;
  }

  sendMessage(msg) {
    this.player.sendMessage(msg);
  }

  runCommand(cmd) {
    try {
      return this.player.runCommandAsync(cmd);
    } catch (e) {
      this.sendMessage(`§cCommand failed: §7${cmd}`);
    }
  }

  get dimension() {
    return this.player.dimension;
  }

  get tags() {
    return this.player.getTags();
  }

  hasTag(tag) {
    return this.player.hasTag(tag);
  }

  addTag(tag) {
    return this.player.addTag(tag);
  }

  removeTag(tag) {
    return this.player.removeTag(tag);
  }

  getRaw() {
    return this.player;
  }
}

const players = new Map();

system.runInterval(() => {
  for (const p of world.getPlayers()) {
    if (!players.has(p.name)) {
      const wrapper = new Player(p);
      players.set(p.name, wrapper);
      if (typeof wrapper._onJoin === 'function') wrapper._onJoin(wrapper);
    }

    const player = players.get(p.name);
    const last = _lastPosMap.get(p.name);
    const now = p.location;

    if (!last || now.x !== last.x || now.y !== last.y || now.z !== last.z) {
      if (typeof player._onMove === 'function') player._onMove(player, last);
      _lastPosMap.set(p.name, { ...now });
    }
  }
}, 2);

export function getPlayer(name) {
  return players.get(name);
}

export function allPlayers() {
  return [...players.values()];
}



const registeredCommands = new Map();
let helpEnabled = false;
let showDescriptions = true;

export function commandBuilder(name, description = '') {
  const command = {
    name,
    description,
    _callback: null,
    _condition: () => true,
    run(callback) {
      this._callback = callback;
      return this;
    },
    if(conditionFn) {
      this._condition = conditionFn;
      return this;
    }
  };

  registeredCommands.set(name, command);
  return command;
}

commandBuilder.setHelp = function (showDesc = true, enabled = true) {
  showDescriptions = showDesc;
  helpEnabled = enabled;
};

world.beforeEvents.chatSend.subscribe(event => {
  const { sender, message } = event;
  if (!message.startsWith('!')) return;

  const args = message.slice(1).split(/\s+/);
  const cmd = args.shift().toLowerCase();

  if (cmd === 'help' && helpEnabled) {
    event.cancel = true;
    sender.sendMessage("§6§lAvailable Commands:");
    for (const [name, cmdData] of registeredCommands) {
      if (!cmdData._condition(sender)) continue;
      if (showDescriptions && cmdData.description) {
        sender.sendMessage(`§e!${name} §7- ${cmdData.description}`);
      } else {
        sender.sendMessage(`§e!${name}`);
      }
    }
    return;
  }

  if (registeredCommands.has(cmd)) {
    const data = registeredCommands.get(cmd);
    if (!data._condition(sender)) return;
    event.cancel = true;
    if (data._callback) data._callback(sender, args);
  } else {
    // Command not found response
    event.cancel = true;
    sender.sendMessage(`§cUnknown command: §f!${cmd}`);
  }
});

import { ModalFormData, ActionFormData } from '@minecraft/server-ui';
import { world } from '@minecraft/server';

let currencyObjective = 'money';

export function setCurrency(objective) {
  currencyObjective = objective;
}

export class SimpleFormBuilder {
  constructor(title = 'Select Option', body = '') {
    this.title = title;
    this.body = body;
    this.form = new ActionFormData().title(title).body(body);
  }

  setTitle(title) {
    this.title = title;
    this.form.title(title);
    return this;
  }

  setBody(body) {
    this.body = body;
    this.form.body(body);
    return this;
  }

  addButton(text, icon) {
    this.form.button(text, icon);
    return this;
  }

  buyButton(text, price, icon) {
    this.form.button(`§a[BUY] §f${text} §7(${price} ${currencyObjective})`, icon);
    return this;
  }

  sellButton(text, price, icon) {
    this.form.button(`§6[SELL] §f${text} §7(+${price} ${currencyObjective})`, icon);
    return this;
  }

  async show(player) {
    const res = await this.form.show(player);
    return res.canceled ? null : res.selection;
  }
}

export class ModalFormBuilder {
  constructor(title = 'Form') {
    this.title = title;
    this.form = new ModalFormData().title(title);
  }

  setTitle(title) {
    this.title = title;
    this.form.title(title);
    return this;
  }

  addDropdown(label, options, defaultIndex = 0) {
    this.form.dropdown(label, options, defaultIndex);
    return this;
  }

  addToggle(label, defaultValue = false) {
    this.form.toggle(label, defaultValue);
    return this;
  }

  addSlider(label, min, max, step = 1, defaultValue = min) {
    this.form.slider(label, min, max, step, defaultValue);
    return this;
  }

  addTextField(label, placeholder = '', defaultValue = '') {
    this.form.textField(label, placeholder, defaultValue);
    return this;
  }

  async show(player) {
    const res = await this.form.show(player);
    return res.canceled ? null : res.formValues;
  }
}


const itemUseHandlers = new Map();

export function setItemUse(player, callback, itemId = null) {
  if (!itemUseHandlers.has(player.name)) itemUseHandlers.set(player.name, []);

  
  const existing = itemUseHandlers.get(player.name);
  const newList = existing.filter(entry => entry.itemId !== itemId);
  newList.push({ callback, itemId });
  itemUseHandlers.set(player.name, newList);
}

world.afterEvents.itemUse.subscribe(event => {
  const { source, itemStack } = event;
  if (!source || !itemUseHandlers.has(source.name)) return;
  for (const entry of itemUseHandlers.get(source.name)) {
    if (!entry.itemId || entry.itemId === itemStack?.typeId) {
      entry.callback(event);
    }
  }
});
class EasyStorage {
  constructor(namespace = 'global') {
      this.namespace = namespace;
      this.data = this.loadData();
  }

  
  loadData() {
      const saved = world.getDynamicProperty(this.namespace);
      return saved ? JSON.parse(saved) : {};
  }

  
  saveData() {
      world.setDynamicProperty(this.namespace, JSON.stringify(this.data));
  }

  
  set(key, value, scope = 'default') {
      if (!this.data[scope]) this.data[scope] = {};
      this.data[scope][key] = value;
      this.saveData();
  }

  
  get(key, defaultValue = null, scope = 'default') {
      return this.data[scope]?.[key] ?? defaultValue;
  }

  
  delete(key, scope = 'default') {
      if (this.data[scope] && key in this.data[scope]) {
          delete this.data[scope][key];
          this.saveData();
          return true;
      }
      return false;
  }

  
  clearScope(scope) {
      if (this.data[scope]) {
          delete this.data[scope];
          this.saveData();
          return true;
      }
      return false;
  }

  
  listKeys(scope = 'default') {
      return this.data[scope] ? Object.keys(this.data[scope]) : [];
  }

  
  listScopes() {
      return Object.keys(this.data);
  }

  
  setPlayerData(player, key, value) {
      this.set(key, value, `player_${player.id}`);
  }

  
  getPlayerData(player, key, defaultValue = null) {
      return this.get(key, defaultValue, `player_${player.id}`);
  }
}

// Instance to data
const storage = new EasyStorage('MyWorldData');


world.afterEvents.playerSpawn.subscribe(event => {
  const player = event.player;
  
  // Save Player Storage
  storage.setPlayerData(player, 'lastLogin', Date.now());
  storage.setPlayerData(player, 'loginCount', 
      (storage.getPlayerData(player, 'loginCount', 0)) + 1);
  
  
  storage.set('totalLogins', 
      (storage.get('totalLogins', 0)) + 1);
  
  player.sendMessage(
      `Welcome #${storage.getPlayerData(player, 'loginCount')}`
  );
});
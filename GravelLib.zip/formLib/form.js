// forms.js - Runtime Implementation of Custom Forms
import { ModalFormData, ActionFormData } from '@minecraft/server-ui';
import { world } from '@minecraft/server';

let currencyObjective = 'money';

export function setCurrency(objective) {
  currencyObjective = objective;
}

export class SimpleFormBuilder {
  constructor(title = 'Select Option', body = '') {
    this.title = title;
    this.body = body;
    this.form = new ActionFormData().title(title).body(body);
  }

  setTitle(title) {
    this.title = title;
    this.form.title(title);
    return this;
  }

  setBody(body) {
    this.body = body;
    this.form.body(body);
    return this;
  }

  addButton(text, icon) {
    this.form.button(text, icon);
    return this;
  }

  buyButton(text, price, icon) {
    this.form.button(`§a[BUY] §f${text} §7(${price} ${currencyObjective})`, icon);
    return this;
  }

  sellButton(text, price, icon) {
    this.form.button(`§6[SELL] §f${text} §7(+${price} ${currencyObjective})`, icon);
    return this;
  }

  async show(player) {
    const res = await this.form.show(player);
    return res.canceled ? null : res.selection;
  }
}

export class ModalFormBuilder {
  constructor(title = 'Form') {
    this.title = title;
    this.form = new ModalFormData().title(title);
  }

  setTitle(title) {
    this.title = title;
    this.form.title(title);
    return this;
  }

  addDropdown(label, options, defaultIndex = 0) {
    this.form.dropdown(label, options, defaultIndex);
    return this;
  }

  addToggle(label, defaultValue = false) {
    this.form.toggle(label, defaultValue);
    return this;
  }

  addSlider(label, min, max, step = 1, defaultValue = min) {
    this.form.slider(label, min, max, step, defaultValue);
    return this;
  }

  addTextField(label, placeholder = '', defaultValue = '') {
    this.form.textField(label, placeholder, defaultValue);
    return this;
  }

  async show(player) {
    const res = await this.form.show(player);
    return res.canceled ? null : res.formValues;
  }
}

// Item use handler system
const itemUseHandlers = new Map();

export function setItemUse(player, callback, itemId = null) {
  if (!itemUseHandlers.has(player.name)) itemUseHandlers.set(player.name, []);

  // Replace previous handlers for the same item
  const existing = itemUseHandlers.get(player.name);
  const newList = existing.filter(entry => entry.itemId !== itemId);
  newList.push({ callback, itemId });
  itemUseHandlers.set(player.name, newList);
}

world.afterEvents.itemUse.subscribe(event => {
  const { source, itemStack } = event;
  if (!source || !itemUseHandlers.has(source.name)) return;
  for (const entry of itemUseHandlers.get(source.name)) {
    if (!entry.itemId || entry.itemId === itemStack?.typeId) {
      entry.callback(event);
    }
  }
});

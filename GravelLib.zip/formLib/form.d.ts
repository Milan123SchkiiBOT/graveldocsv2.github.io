// CustomFormBuilder.ts - Simple Custom Form UI Builder for Minecraft Bedrock ScriptAPI
import { ModalFormData, ActionFormData } from '@minecraft/server-ui';
import { Player } from '@minecraft/server';

declare class SimpleFormBuilder {
  private form: ActionFormData;
  constructor(title?: string, body?: string);
  addButton(text: string, icon?: string): this;
  show(player: Player): Promise<number | null>;
}

declare class ModalFormBuilder {
  private form: ModalFormData;
  constructor(title?: string);
  addDropdown(label: string, options: string[], defaultIndex?: number): this;
  addToggle(label: string, defaultValue?: boolean): this;
  addSlider(label: string, min: number, max: number, step?: number, defaultValue?: number): this;
  addTextField(label: string, placeholder?: string, defaultValue?: string): this;
  show(player: Player): Promise<any[] | null>;
}

export { SimpleFormBuilder, ModalFormBuilder };

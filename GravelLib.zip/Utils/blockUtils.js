/**
 * BlockUtils - Advanced block manipulation library for Minecraft Bedrock ScriptAPI
 * Provides features beyond the standard API including ghost blocks, block properties, and custom block events
 */
// Imports
import { world, Player, system } from "@minecraft/server"

class BlockUtils {
    constructor() {
        this._blockProperties = new Map();
        this._ghostBlocks = new Map();
        this._registeredBlockEvents = new Map();
        
        // Set up world tick event for block updates
        world.afterEvents.tick.subscribe(() => {
            this._processBlockEvents();
            this._updateGhostBlocks();
        });
    }

    // ==============================================
    // GHOST BLOCKS SYSTEM (Client-side fake blocks)
    // ==============================================

    /**
     * Creates a ghost block (client-side only)
     * @param {Vector3} location - Block position
     * @param {string} blockType - Minecraft block ID
     * @param {Player} player - Specific player to show the block to (optional)
     */
    createGhostBlock(location, blockType, player = null) {
        const key = `${location.x},${location.y},${location.z}`;
        const ghostBlock = { location, blockType, players: player ? [player] : [] };
        
        this._ghostBlocks.set(key, ghostBlock);
        
        // Immediately show to player
        if (player) {
            this._sendGhostBlockUpdate(player, location, blockType);
        }
    }

    /**
     * Removes a ghost block
     * @param {Vector3} location - Block position
     * @param {Player} player - Specific player to remove for (optional)
     */
    removeGhostBlock(location, player = null) {
        const key = `${location.x},${location.y},${location.z}`;
        
        if (player) {
            const ghost = this._ghostBlocks.get(key);
            if (ghost) {
                ghost.players = ghost.players.filter(p => p.id !== player.id);
                this._sendGhostBlockUpdate(player, location, 'minecraft:air');
                
                if (ghost.players.length === 0) {
                    this._ghostBlocks.delete(key);
                }
            }
        } else {
            this._ghostBlocks.delete(key);
            // Send air block to all players in the world
            world.getPlayers().forEach(p => {
                this._sendGhostBlockUpdate(p, location, 'minecraft:air');
            });
        }
    }

    /**
     * Internal: Sends block update to player's client
     * @private
     */
    _sendGhostBlockUpdate(player, location, blockType) {
        player.runCommandAsync(
            `setblock ${location.x} ${location.y} ${location.z} ${blockType} destroy`
        );
    }

    /**
     * Internal: Maintains ghost blocks for all players
     * @private
     */
    _updateGhostBlocks() {
        // Only run every 10 ticks for performance
        if (system.currentTick % 10 !== 0) return;
        
        this._ghostBlocks.forEach((ghostBlock, key) => {
            const targets = ghostBlock.players.length > 0 
                ? ghostBlock.players 
                : world.getPlayers();
            
            targets.forEach(player => {
                this._sendGhostBlockUpdate(player, ghostBlock.location, ghostBlock.blockType);
            });
        });
    }

    // ==============================================
    // BLOCK PROPERTIES SYSTEM (Custom block data)
    // ==============================================

    /**
     * Sets custom property for a block
     * @param {Vector3} location - Block position
     * @param {string} key - Property name
     * @param {any} value - Property value (must be JSON-serializable)
     */
    setBlockProperty(location, key, value) {
        const blockKey = this._getBlockKey(location);
        let properties = this._blockProperties.get(blockKey) || {};
        
        properties[key] = value;
        this._blockProperties.set(blockKey, properties);
    }

    /**
     * Gets custom property from a block
     * @param {Vector3} location - Block position
     * @param {string} key - Property name
     * @param {any} defaultValue - Default value if property doesn't exist
     */
    getBlockProperty(location, key, defaultValue = null) {
        const blockKey = this._getBlockKey(location);
        const properties = this._blockProperties.get(blockKey);
        
        return properties?.[key] ?? defaultValue;
    }

    /**
     * Deletes a custom property from a block
     * @param {Vector3} location - Block position
     * @param {string} key - Property name
     */
    deleteBlockProperty(location, key) {
        const blockKey = this._getBlockKey(location);
        const properties = this._blockProperties.get(blockKey);
        
        if (properties && key in properties) {
            delete properties[key];
            this._blockProperties.set(blockKey, properties);
            return true;
        }
        return false;
    }

    /**
     * Internal: Creates a unique key for block position
     * @private
     */
    _getBlockKey(location) {
        return `${Math.floor(location.x)},${Math.floor(location.y)},${Math.floor(location.z)}`;
    }

    // ==============================================
    // BLOCK EVENT SYSTEM (Custom block interactions)
    // ==============================================

    /**
     * Registers a custom event handler for a block type
     * @param {string} blockType - Minecraft block ID
     * @param {Object} events - Event handlers
     * @param {Function} events.onInteract - Called when player interacts with block
     * @param {Function} events.onStepOn - Called when player steps on block
     * @param {Function} events.onDestroy - Called when block is destroyed
     */
    registerBlockEvents(blockType, events) {
        this._registeredBlockEvents.set(blockType, events);
    }

    /**
     * Internal: Processes block events each tick
     * @private
     */
    _processBlockEvents() {
        // Only run every 5 ticks for performance
        if (system.currentTick % 5 !== 0) return;
        
        // Check player interactions
        world.getPlayers().forEach(player => {
            const block = this._getTargetedBlock(player, 5);
            if (block && this._registeredBlockEvents.has(block.typeId)) {
                const events = this._registeredBlockEvents.get(block.typeId);
                
                // Check if player is looking at the block (for interact events)
                if (this._isPlayerLookingAt(player, block.location)) {
                    if (events.onInteract && player.isSneaking) {
                        events.onInteract(block, player);
                    }
                }
                
                // Check if player is standing on the block
                const feetPos = {
                    x: Math.floor(player.location.x),
                    y: Math.floor(player.location.y - 0.3),
                    z: Math.floor(player.location.z)
                };
                
                if (this._sameBlockPos(feetPos, block.location)) {
                    if (events.onStepOn) {
                        events.onStepOn(block, player);
                    }
                }
            }
        });
    }

    /**
     * Internal: Gets the block a player is targeting
     * @private
     */
    _getTargetedBlock(player, maxDistance) {
        const viewDir = this._getViewDirection(player);
        const startPos = player.location;
        
        for (let i = 0; i < maxDistance; i += 0.2) {
            const checkPos = {
                x: startPos.x + viewDir.x * i,
                y: startPos.y + viewDir.y * i,
                z: startPos.z + viewDir.z * i
            };
            
            const block = player.dimension.getBlock(checkPos);
            if (block && block.typeId !== 'minecraft:air') {
                return block;
            }
        }
        return null;
    }

    /**
     * Internal: Gets player's view direction
     * @private
     */
    _getViewDirection(player) {
        const rotation = player.getRotation();
        const yawRad = rotation.y * (Math.PI / 180);
        const pitchRad = rotation.x * (Math.PI / 180);
        
        return {
            x: -Math.sin(yawRad) * Math.cos(pitchRad),
            y: -Math.sin(pitchRad),
            z: Math.cos(yawRad) * Math.cos(pitchRad)
        };
    }

    /**
     * Internal: Checks if player is looking at a position
     * @private
     */
    _isPlayerLookingAt(player, position, maxAngle = 15) {
        const dir = {
            x: position.x - player.location.x,
            y: position.y - player.location.y,
            z: position.z - player.location.z
        };
        
        const length = Math.sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
        if (length === 0) return true;
        
        const normDir = {
            x: dir.x / length,
            y: dir.y / length,
            z: dir.z / length
        };
        
        const viewDir = this._getViewDirection(player);
        const dot = normDir.x * viewDir.x + normDir.y * viewDir.y + normDir.z * viewDir.z;
        const angle = Math.acos(dot) * (180 / Math.PI);
        
        return angle <= maxAngle;
    }

    /**
     * Internal: Compares two block positions
     * @private
     */
    _sameBlockPos(pos1, pos2) {
        return Math.floor(pos1.x) === Math.floor(pos2.x) &&
               Math.floor(pos1.y) === Math.floor(pos2.y) &&
               Math.floor(pos1.z) === Math.floor(pos2.z);
    }

    // ==============================================
    // UTILITY FUNCTIONS (Helpful block operations)
    // ==============================================

    /**
     * Replaces all blocks of a type in an area
     * @param {Vector3} start - Start corner of area
     * @param {Vector3} end - End corner of area
     * @param {string} fromBlock - Block type to replace
     * @param {string} toBlock - New block type
     */
    replaceBlocksInArea(start, end, fromBlock, toBlock) {
        const minX = Math.min(start.x, end.x);
        const minY = Math.min(start.y, end.y);
        const minZ = Math.min(start.z, end.z);
        const maxX = Math.max(start.x, end.x);
        const maxY = Math.max(start.y, end.y);
        const maxZ = Math.max(start.z, end.z);
        
        for (let x = minX; x <= maxX; x++) {
            for (let y = minY; y <= maxY; y++) {
                for (let z = minZ; z <= maxZ; z++) {
                    const pos = { x, y, z };
                    const block = world.getDimension('overworld').getBlock(pos);
                    if (block && block.typeId === fromBlock) {
                        block.setType(toBlock);
                    }
                }
            }
        }
    }

    /**
     * Creates a temporary exploding block effect
     * @param {Vector3} location - Center position
     * @param {string} blockType - Block type to visualize
     * @param {number} duration - Effect duration in ticks
     */
    createExplosionEffect(location, blockType = 'minecraft:tnt', duration = 20) {
        // Create temporary ghost blocks in explosion pattern
        const pattern = [
            {x:0,y:0,z:0}, {x:1,y:0,z:0}, {x:-1,y:0,z:0},
            {x:0,y:1,z:0}, {x:0,y:-1,z:0}, {x:0,y:0,z:1},
            {x:0,y:0,z:-1}, {x:1,y:1,z:0}, {x:-1,y:-1,z:0}
        ];
        
        pattern.forEach(offset => {
            const pos = {
                x: location.x + offset.x,
                y: location.y + offset.y,
                z: location.z + offset.z
            };
            
            this.createGhostBlock(pos, blockType);
        });
        
        // Remove after duration
        system.runTimeout(() => {
            pattern.forEach(offset => {
                const pos = {
                    x: location.x + offset.x,
                    y: location.y + offset.y,
                    z: location.z + offset.z
                };
                this.removeGhostBlock(pos);
            });
        }, duration);
    }
}

// Initialize BlockUtils as a global singleton
const blockUtils = new BlockUtils();

// ==============================================
// EXAMPLE USAGE
// ==============================================

// Register custom block events
blockUtils.registerBlockEvents('minecraft:stone', {
    onInteract: (block, player) => {
        player.sendMessage('You interacted with special stone!');
        blockUtils.setBlockProperty(block.location, 'lastInteracted', player.name);
    },
    onStepOn: (block, player) => {
        player.sendMessage('You stepped on special stone!');
        blockUtils.createExplosionEffect(block.location, 'minecraft:redstone_block', 30);
    }
});

// Create ghost blocks for a parkour course
world.afterEvents.worldInitialize.subscribe(() => {
    for (let i = 0; i < 10; i++) {
        blockUtils.createGhostBlock(
            {x: 100, y: 70 + i, z: 200},
            'minecraft:barrier'
        );
    }
});

// Example command to set block properties
world.beforeEvents.chatSend.subscribe(event => {
    const [cmd, ...args] = event.message.split(' ');
    const player = event.sender;
    
    if (cmd === '!setblockdata') {
        const block = blockUtils._getTargetedBlock(player, 5);
        if (block) {
            blockUtils.setBlockProperty(block.location, args[0], args.slice(1).join(' '));
            player.sendMessage(`Set property '${args[0]}' for ${block.typeId}`);
            event.cancel = true;
        }
    }
});
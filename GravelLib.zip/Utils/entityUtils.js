// EntityEvents.js - Erweiterte Entity-Events
import { world, system } from '@minecraft/server';


class EntityEvents {
    static _spawn = new Map();
    static _spawnCallbacks = [];
    static _hurtCallbacks = [];
    static _deathCallbacks = [];
  
    static onSpawn(typeId, callback) {
      if (typeof callback === 'function')
        this._spawnCallbacks.push({ typeId, fn: callback });
    }
  
    static onHurt(callback) {
      if (typeof callback === 'function')
        this._hurtCallbacks.push(callback);
    }
  
    static onDeath(callback) {
      if (typeof callback === 'function')
        this._deathCallbacks.push(callback);
    }
  
    static _scanEntities() {
      const overworld = world.getDimension("overworld");
      const entities = overworld.getEntities();
  
      for (const entity of entities) {
        if (!this._spawn.has(entity.id)) {
          this._spawn.set(entity.id, true);
          for (const hook of this._spawnCallbacks) {
            if (!hook.typeId || entity.typeId === hook.typeId) {
              try {
                hook.fn(entity);
              } catch (e) {
                console.warn("EntityEvents.Spawn Error:", e);
              }
            }
          }
        }
      }
    }
  
    static init() {
      world.afterEvents.entityHurt.subscribe(event => {
        for (const cb of this._hurtCallbacks) {
          try {
            cb(event);
          } catch (e) {
            console.warn("EntityEvents.Hurt Error:", e);
          }
        }
      });
  
      world.afterEvents.entityDie.subscribe(event => {
        for (const cb of this._deathCallbacks) {
          try {
            cb(event);
          } catch (e) {
            console.warn("EntityEvents.Death Error:", e);
          }
        }
      });
  
      system.runInterval(() => this._scanEntities(), 10);
    }
  }
  
  EntityEvents.init();
  

// Kurzschreibweise z.B. EntityEvents.Hurt(cb)
EntityEvents.Spawn = EntityEvents.onSpawn;
EntityEvents.Hurt = EntityEvents.onHurt;
EntityEvents.Death = EntityEvents.onDeath;

EntityEvents.init();
export { EntityEvents };

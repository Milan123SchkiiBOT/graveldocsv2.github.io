// PlayerUtils.js - Erweiterte Spielerfunktionen
import { world, system } from '@minecraft/server';

export class PlayerUtils {

  /** Get currently held item */
  static getHeldItem(player) {
    return player.getComponent("minecraft:inventory")?.container.getItem(player.selectedSlot);
  }

  /** Check if player has specific item */
  static hasItem(player, typeId, count = 1) {
    const inv = player.getComponent("minecraft:inventory")?.container;
    if (!inv) return false;
    let total = 0;
    for (let i = 0; i < inv.size; i++) {
      const item = inv.getItem(i);
      if (item && item.typeId === typeId) total += item.amount;
      if (total >= count) return true;
    }
    return false;
  }

  /** Disable player jump by giving jump_boost 128 */
  static disableJump(player) {
    player.addEffect("jump_boost", 999999, { amplifier: 128 });
  }

  /** Force player into sneak mode */
  static forceSneak(player) {
    player.runCommandAsync("inputpermission set @s sneak disabled");
    player.runCommandAsync("inputpermission set @s movement disabled");
    system.runTimeout(() => player.runCommandAsync("inputpermission set @s movement enabled"), 2);
  }

  /** Respawn player (simulated) */
  static respawn(player) {
    player.runCommandAsync(`kill @s`);
  }

  /** Get block player is looking at (approx) */
  static getLookingBlock(player, maxDistance = 5) {
    const eyePos = player.getHeadLocation();
    const view = player.viewVector;
    for (let i = 1; i <= maxDistance; i++) {
      const x = eyePos.x + view.x * i;
      const y = eyePos.y + view.y * i;
      const z = eyePos.z + view.z * i;
      const block = player.dimension.getBlock({ x, y, z });
      if (block && block.typeId !== "minecraft:air") return block;
    }
    return null;
  }
}

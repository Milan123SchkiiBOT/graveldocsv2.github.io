// WorldEvents.js - Simulierte Welt-Events
import { world, system } from '@minecraft/server';

export class WorldEvents {
  static _time = 0;
  static _isRaining = false;
  static _tick = 0;
  static _onTimeChange = [];
  static _onRainStart = [];
  static _onRainStop = [];
  static _onExplosion = [];
  static _onLightning = [];

  /** Register time change callback */
  static onTimeChange(callback) {
    this._onTimeChange.push(callback);
  }

  /** Register when rain starts */
  static onRainStart(callback) {
    this._onRainStart.push(callback);
  }

  /** Register when rain ends */
  static onRainStop(callback) {
    this._onRainStop.push(callback);
  }

  /** Register explosion (simulated) */
  static onExplosion(callback) {
    this._onExplosion.push(callback);
  }

  /** Register lightning (simulated) */
  static onLightning(callback) {
    this._onLightning.push(callback);
  }

  /** Run internal tick checker */
  static init() {
    system.runInterval(() => {
      this._tick++;
      const time = world.getTimeOfDay();
      if (time !== this._time) {
        this._onTimeChange.forEach(cb => cb(time));
        this._time = time;
      }

      const rainingNow = world.getDimension("overworld").weather === "rain";
      if (rainingNow !== this._isRaining) {
        this._isRaining = rainingNow;
        if (rainingNow) this._onRainStart.forEach(cb => cb());
        else this._onRainStop.forEach(cb => cb());
      }
    }, 5);

    // Listen for explosions
    world.afterEvents.explosion.subscribe(e => this._onExplosion.forEach(cb => cb(e)));

    // Listen for lightning via weather change
    world.afterEvents.weatherChange?.subscribe(e => {
      if (e.newWeather === "thunderstorm") this._onLightning.forEach(cb => cb(e));
    });
  }
}

WorldEvents.init();

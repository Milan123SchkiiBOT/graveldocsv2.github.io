import { ItemStack, Player, Dimension } from "@minecraft/server"
import { EasyStorage } from "../database/EasyStorage";
class InventorySystem {
  constructor() {
      this.storage = new EasyStorage('InventoryData');
      this._itemCache = new Map();
  }

  // ======================
  // BASIC INVENTORY OPERATIONS
  // ======================

  /**
   * Adds an item to player's inventory
   * @param {Player} player 
   * @param {string} itemId 
   * @param {number} amount 
   * @param {object} [data] - Additional item data
   * @returns {boolean} True if item was added successfully
   */
  addItem(player, itemId, amount = 1, data = {}) {
      const container = player.getComponent('minecraft:inventory').container;
      const itemStack = new ItemStack(itemId, amount);
      
      // Apply custom data if provided
      if (data.name) itemStack.nameTag = data.name;
      if (data.lore) itemStack.setLore(data.lore);
      if (data.enchantments) {
          this._applyEnchantments(itemStack, data.enchantments);
      }
      
      return container.addItem(itemStack);
  }

  /**
   * Removes an item from player's inventory
   * @param {Player} player 
   * @param {string} itemId 
   * @param {number} amount 
   * @returns {boolean} True if items were removed
   */
  removeItem(player, itemId, amount = 1) {
      const container = player.getComponent('minecraft:inventory').container;
      let remaining = amount;
      
      for (let i = 0; i < container.size; i++) {
          const item = container.getItem(i);
          if (item && item.typeId === itemId) {
              const removeCount = Math.min(item.amount, remaining);
              item.amount -= removeCount;
              remaining -= removeCount;
              
              if (item.amount <= 0) {
                  container.setItem(i, undefined);
              } else {
                  container.setItem(i, item);
              }
              
              if (remaining <= 0) break;
          }
      }
      
      return remaining === 0;
  }

  // ======================
  // ITEM STACK OPERATIONS
  // ======================

  /**
   * Creates a custom item stack
   * @param {string} itemId 
   * @param {number} amount 
   * @param {object} [data] 
   * @returns {ItemStack}
   */
  createItemStack(itemId, amount = 1, data = {}) {
      const itemStack = new ItemStack(itemId, amount);
      
      if (data.name) itemStack.nameTag = data.name;
      if (data.lore) itemStack.setLore(data.lore);
      if (data.enchantments) {
          this._applyEnchantments(itemStack, data.enchantments);
      }
      if (data.durability) {
          itemStack.getComponent('minecraft:durability').damage = data.durability;
      }
      
      // Cache the item for later retrieval
      if (data.id) {
          this._itemCache.set(data.id, itemStack);
      }
      
      return itemStack;
  }

  /**
   * Spawns an item in the world
   * @param {Dimension} dimension 
   * @param {Vector3} location 
   * @param {ItemStack|string} item - ItemStack or item ID
   * @param {number} [amount] - Required if item is ID
   */
  spawnItem(dimension, location, item, amount = 1) {
      let itemStack;
      
      if (typeof item === 'string') {
          itemStack = new ItemStack(item, amount);
      } else {
          itemStack = item;
      }
      
      dimension.spawnItem(itemStack, location);
  }

  // ======================
  // ENCHANTMENT SYSTEM
  // ======================

  /**
   * Enchants an item in specific slot
   * @param {Player} player 
   * @param {number} slot 
   * @param {string} enchantmentId 
   * @param {number} level 
   * @returns {boolean} True if enchantment was applied
   */
  enchantItemInSlot(player, slot, enchantmentId, level = 1) {
      const container = player.getComponent('minecraft:inventory').container;
      const item = container.getItem(slot);
      
      if (!item) return false;
      
      const enchantmentComponent = item.getComponent('minecraft:enchantments');
      if (!enchantmentComponent) return false;
      
      const enchantments = enchantmentComponent.enchantments;
      enchantments.addEnchantment({ type: enchantmentId, level });
      return enchantmentComponent.enchantments = enchantments;
  }

  /**
   * Removes all enchantments from item in slot
   * @param {Player} player 
   * @param {number} slot 
   */
  clearEnchantments(player, slot) {
      const container = player.getComponent('minecraft:inventory').container;
      const item = container.getItem(slot);
      
      if (!item) return false;
      
      const enchantmentComponent = item.getComponent('minecraft:enchantments');
      if (!enchantmentComponent) return false;
      
      const enchantments = enchantmentComponent.enchantments;
      enchantments.removeAllEnchantments();
      return enchantmentComponent.enchantments = enchantments;
  }

  // ======================
  // INVENTORY VISUALIZATION
  // ======================

  /**
   * Shows a fake inventory to player
   * @param {Player} player 
   * @param {string} title 
   * @param {Array} items - Array of item definitions
   */
  async showFakeInventory(player, title, items) {
      // This requires creative use of commands to simulate a custom inventory
      // Note: This is a simplified version that uses chat-based menus
      
      let message = `§6${title}\n`;
      items.forEach((item, index) => {
          message += `§${index % 2 === 0 ? 'a' : 'b'}${index + 1}. ${item.name}\n`;
      });
      
      player.sendMessage(message);
      
      // Store the menu context for handling selection
      this.storage.setPlayerData(player, 'currentMenu', {
          items,
          timestamp: Date.now()
      });
  }

  // ======================
  // INVENTORY SAVE/LOAD SYSTEM
  // ======================

  /**
   * Saves player's inventory to storage
   * @param {Player} player 
   */
  saveInventory(player) {
      const container = player.getComponent('minecraft:inventory').container;
      const inventoryData = [];
      
      for (let i = 0; i < container.size; i++) {
          const item = container.getItem(i);
          if (item) {
              inventoryData.push(this._serializeItemStack(item));
          }
      }
      
      this.storage.setPlayerData(player, 'inventory', inventoryData);
  }

  /**
   * Loads player's inventory from storage
   * @param {Player} player 
   */
  loadInventory(player) {
      const container = player.getComponent('minecraft:inventory').container;
      const inventoryData = this.storage.getPlayerData(player, 'inventory', []);
      
      // Clear current inventory first
      this.clearInventory(player);
      
      // Load saved items
      inventoryData.forEach((itemData, slot) => {
          if (itemData) {
              const itemStack = this._deserializeItemStack(itemData);
              container.setItem(slot, itemStack);
          }
      });
  }

  /**
   * Clears player's inventory
   * @param {Player} player 
   */
  clearInventory(player) {
      const container = player.getComponent('minecraft:inventory').container;
      for (let i = 0; i < container.size; i++) {
          container.setItem(i, undefined);
      }
  }

  // ======================
  // PRIVATE HELPERS
  // ======================

  /**
   * Applies enchantments to an item stack
   * @private
   */
  _applyEnchantments(itemStack, enchantments) {
      const enchantmentComponent = itemStack.getComponent('minecraft:enchantments');
      if (!enchantmentComponent) return;
      
      const enchantmentList = enchantmentComponent.enchantments;
      
      Object.entries(enchantments).forEach(([id, level]) => {
          enchantmentList.addEnchantment({ type: id, level });
      });
      
      enchantmentComponent.enchantments = enchantmentList;
  }

  /**
   * Serializes an item stack for storage
   * @private
   */
  _serializeItemStack(item) {
      return {
          typeId: item.typeId,
          amount: item.amount,
          name: item.nameTag,
          lore: item.getLore(),
          durability: item.getComponent('minecraft:durability')?.damage,
          enchantments: this._getEnchantments(item)
      };
  }

  /**
   * Deserializes an item stack from storage data
   * @private
   */
  _deserializeItemStack(data) {
      const itemStack = new ItemStack(data.typeId, data.amount);
      
      if (data.name) itemStack.nameTag = data.name;
      if (data.lore) itemStack.setLore(data.lore);
      if (data.durability) {
          itemStack.getComponent('minecraft:durability').damage = data.durability;
      }
      if (data.enchantments) {
          this._applyEnchantments(itemStack, data.enchantments);
      }
      
      return itemStack;
  }

  /**
   * Extracts enchantments from an item
   * @private
   */
  _getEnchantments(item) {
      const enchantmentComponent = item.getComponent('minecraft:enchantments');
      if (!enchantmentComponent) return {};
      
      const enchantments = {};
      enchantmentComponent.enchantments.forEach(enchant => {
          enchantments[enchant.type] = enchant.level;
      });
      
      return enchantments;
  }
}



// Initialize as a global singleton
// const inventorySystem = new InventorySystem();

// ======================
// EXAMPLE USAGE
// ======================

/** 

// Save/load inventory on player join/quit
world.afterEvents.playerSpawn.subscribe(event => {
  inventorySystem.loadInventory(event.player);
});

world.afterEvents.playerLeave.subscribe(event => {
  inventorySystem.saveInventory(event.player);
});

// Example command to give custom items
world.beforeEvents.chatSend.subscribe(event => {
  const [cmd, itemId, amountStr] = event.message.split(' ');
  const player = event.sender;
  
  if (cmd === '!give') {
      const amount = parseInt(amountStr) || 1;
      
      // Create custom item
      const customItem = inventorySystem.createItemStack(itemId, amount, {
          name: `§6Special ${itemId}`,
          lore: ['§7A custom crafted item', '§aCreated by the server'],
          enchantments: {
              'minecraft:sharpness': 3,
              'minecraft:unbreaking': 2
          }
      });
      
      // Add to player inventory
      if (inventorySystem.addItem(player, customItem)) {
          player.sendMessage(`You received a special ${itemId}!`);
      } else {
          player.sendMessage(`Couldn't give ${itemId} - inventory full?`);
      }
      
      event.cancel = true;
  }
});

// Example for spawning items
world.beforeEvents.chatSend.subscribe(event => {
  const [cmd, itemId, amountStr] = event.message.split(' ');
  const player = event.sender;
  
  if (cmd === '!spawnitem') {
      const amount = parseInt(amountStr) || 1;
      const location = player.location;
      
      inventorySystem.spawnItem(
          player.dimension,
          { x: location.x, y: location.y + 1, z: location.z },
          itemId,
          amount
      );
      
      player.sendMessage(`Spawned ${amount} ${itemId} above you!`);
      event.cancel = true;
  }
});
*/
export { InventorySystem }
// InventoryUtils.js - Inventar-Funktionen
import { ItemStack } from '@minecraft/server';

export class InventoryUtils {

  /** Clear player inventory */
  static clear(player) {
    const inv = player.getComponent("inventory")?.container;
    if (!inv) return;
    for (let i = 0; i < inv.size; i++) {
      inv.setItem(i, undefined);
    }
  }

  /** Replace item in specific slot */
  static replaceItem(player, slot, itemStack) {
    const inv = player.getComponent("inventory")?.container;
    if (!inv) return;
    inv.setItem(slot, itemStack instanceof ItemStack ? itemStack : undefined);
  }

  /** Get all items in inventory */
  static getAll(player) {
    const inv = player.getComponent("inventory")?.container;
    if (!inv) return [];
    const result = [];
    for (let i = 0; i < inv.size; i++) {
      const item = inv.getItem(i);
      if (item) result.push(item);
    }
    return result;
  }

  /** Count how many of a certain item a player has */
  static count(player, typeId) {
    const inv = player.getComponent("inventory")?.container;
    if (!inv) return 0;
    let total = 0;
    for (let i = 0; i < inv.size; i++) {
      const item = inv.getItem(i);
      if (item && item.typeId === typeId) total += item.amount;
    }
    return total;
  }

  /** Remove specific amount of item */
  static remove(player, typeId, amount = 1) {
    const inv = player.getComponent("inventory")?.container;
    if (!inv) return;
    let left = amount;
    for (let i = 0; i < inv.size; i++) {
      const item = inv.getItem(i);
      if (!item || item.typeId !== typeId) continue;
      if (item.amount > left) {
        item.amount -= left;
        inv.setItem(i, item);
        return;
      } else {
        left -= item.amount;
        inv.setItem(i, undefined);
      }
      if (left <= 0) return;
    }
  }
}
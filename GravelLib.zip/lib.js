import "./player/player"
import "./player/setPermisson"


import { system, world, Player, EntityInventoryComponent, ItemStack, BlockPermutation, Vector } from '@minecraft/server';

export class UltraLib {

  static blockPermissions = { place: {}, break: {} };

  /** Send a stylized message to a player */
  static sendMessage(player, text, style = '§b§l[UltraLib] §r§7') {
    player.sendMessage(`${style}${text}`);
  }

  /** Get a player's inventory component easily */
  static getInventory(player) {
    return player.getComponent(EntityInventoryComponent.componentId).container;
  }

  /** Quickly give an item to a player */
  static giveItem(player, itemId, amount = 1, data = 0) {
    const inventory = UltraLib.getInventory(player);
    const item = new ItemStack(itemId, amount, data);
    inventory.addItem(item);
  }

  /** Clear specific items from player's inventory */
  static clearItem(player, itemId) {
    const inventory = UltraLib.getInventory(player);
    for (let slot = 0; slot < inventory.size; slot++) {
      const item = inventory.getItem(slot);
      if (item && item.typeId === itemId) {
        inventory.setItem(slot, undefined);
      }
    }
  }

  /** Teleport a player safely to a location */
  static safeTeleport(player, location) {
    player.teleport(Vector.add(location, { x: 0.5, y: 1, z: 0.5 }), player.dimension, 0, 0);
    UltraLib.sendMessage(player, 'Teleported successfully!');
  }

  /** Set a block at a location with permutation */
  static setBlock(location, blockId, states = {}) {
    const permutation = BlockPermutation.resolve(blockId, states);
    world.getDimension('overworld').getBlock(location).setPermutation(permutation);
  }

  /** Easy event registration */
  static onPlayerJoin(callback) {
    system.afterEvents.scriptEventReceive.subscribe((event) => {
      if (event.id === 'minecraft:player_joined') callback(event.sourceEntity);
    });
  }

  /** Easy item-drop function */
  static dropItem(location, itemId, amount = 1, data = 0) {
    const item = new ItemStack(itemId, amount, data);
    world.getDimension('overworld').spawnItem(item, location);
  }

  /** Spawn particle effects easily */
  static spawnParticle(particleId, location) {
    world.getDimension('overworld').spawnParticle(particleId, location);
  }

  /** Run a repeating task */
  static repeatTask(callback, interval = 20) {
    system.runInterval(() => callback(), interval);
  }

  /** Check if a player has a certain tag */
  static hasTag(player, tag) {
    return player.hasTag(tag);
  }

  /** Easily toggle player tag */
  static toggleTag(player, tag) {
    if (UltraLib.hasTag(player, tag)) player.removeTag(tag);
    else player.addTag(tag);
  }

  /** Simple scoreboard manipulation */
  static setScore(player, objective, value) {
    world.scoreboard.getObjective(objective).setScore(player.scoreboardIdentity, value);
  }

  static getScore(player, objective) {
    return world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity);
  }

  /** Set player block permissions (place or break) */
  static setPlayerBlockPermission(player, action, type, message) {
    if (!UltraLib.blockPermissions[action][player.name]) UltraLib.blockPermissions[action][player.name] = [];
    UltraLib.blockPermissions[action][player.name].push({ type, message });
  }

  /** Handle block place event */
  static handleBlockPlace(player, block) {
    const perms = UltraLib.blockPermissions.place[player.name];
    if (perms) {
      for (let perm of perms) {
        if (perm.type === 'all' || perm.type === block.typeId || (Array.isArray(perm.type) && perm.type.includes(block.typeId))) {
          UltraLib.sendMessage(player, perm.message);
          block.setPermutation(BlockPermutation.resolve('minecraft:air'));
          break;
        }
      }
    }
  }

  /** Handle block break event */
  static handleBlockBreak(player, block) {
    const perms = UltraLib.blockPermissions.break[player.name];
    if (perms) {
      for (let perm of perms) {
        if (perm.type === 'all' || perm.type === block.typeId || (Array.isArray(perm.type) && perm.type.includes(block.typeId))) {
          UltraLib.sendMessage(player, perm.message);
          UltraLib.setBlock(block.location, block.typeId);
          break;
        }
      }
    }
  }

}

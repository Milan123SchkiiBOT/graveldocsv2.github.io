// UIStorage + UIBuilder
import { world, system } from '@minecraft/server';
import { ModalFormData } from '@minecraft/server-ui'

const savedUIs = new Map();

export class UIStorage {
  static save(name, data) {
    savedUIs.set(name, data);
  }

  static load(name) {
    return savedUIs.get(name);
  }

  static list() {
    return [...savedUIs.keys()];
  }
}

export class UIBuilder {
  constructor(title = "") {
    this.title = title;
    this.elements = [];
    this.submitCallback = null;
  }

  setTitle(title) {
    this.title = title;
    return this;
  }

  addButton(text, icon = "", onClick = null) {
    this.elements.push({ type: "button", text, icon, onClick });
    return this;
  }

  addInput(label, placeholder = "") {
    this.elements.push({ type: "input", label, placeholder });
    return this;
  }

  onSubmit(callback) {
    this.submitCallback = callback;
    return this;
  }

  show(player) {
    const form = new ModalFormData().title(this.title);
    this.elements.forEach(el => {
      if (el.type === "input") form.textField(el.label, el.placeholder);
    });

    return form.show(player).then(res => {
      if (res.canceled) return;
      if (this.submitCallback) this.submitCallback(player, res.formValues);
    });
  }

  static fromStorage(name) {
    const data = UIStorage.load(name);
    if (!data) return null;
    const builder = new UIBuilder(data.title);
    builder.elements = data.elements;
    return builder;
  }

  save(name) {
    UIStorage.save(name, {
      title: this.title,
      elements: this.elements
    });
  }
} // 🔚

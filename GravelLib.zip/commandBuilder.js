import { world, system } from "@minecraft/server";

const prefix = "!";
let enabled = false;
const commands = new Map();

export const commandBuilder = {
  toggle(value = true) {
    enabled = value;
    if (enabled) {
      world.beforeEvents.chatSend.subscribe((msg) => {
        const message = msg.message;
        if (!message.startsWith(prefix)) return;
        msg.cancel = true;
        handleCommand(msg.sender, message.slice(prefix.length));
      });
    }
  },

  register(name, options) {
    if (!name || typeof options.execute !== "function")
      throw new Error("Command needs name and execute(player, args)");

    commands.set(name.toLowerCase(), {
      name,
      description: options.description || "No description.",
      usage: options.usage || `!${name}`,
      aliases: options.aliases || [],
      execute: options.execute,
    });
  },

  getAll() {
    return Array.from(commands.values());
  },
};

function handleCommand(player, raw) {
  const [name, ...args] = raw.trim().split(/\s+/);
  const cmd =
    commands.get(name.toLowerCase()) ||
    Array.from(commands.values()).find((c) => c.aliases.includes(name.toLowerCase()));

  if (!cmd) {
    player.sendMessage(`§cUnknown command. Try "!help"`);
    return;
  }

  try {
    cmd.execute(player, args);
  } catch (e) {
    player.sendMessage(`§cError: ${e.message}`);
    console.warn(`[Command Error] ${cmd.name}: ${e}`);
  }
}

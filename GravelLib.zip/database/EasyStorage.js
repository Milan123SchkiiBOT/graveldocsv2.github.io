/**
 * EasyStorage - Simple persistent data storage for Minecraft Bedrock ScriptAPI
 * Uses world dynamic properties to save data across game sessions
 */
import { world, system, Player, ItemStack } from "@minecraft/server"

export class EasyStorage {
    /**
     * @param {string} namespace - Storage namespace (default: 'global')
     */
    constructor(namespace = 'global') {
        this.namespace = namespace;
    }

    /**
     * Save data to storage
     * @param {string} key 
     * @param {any} value - Must be JSON-serializable
     */
    set(key, value) {
        const data = this._loadAll();
        data[key] = value;
        world.setDynamicProperty(this.namespace, JSON.stringify(data));
    }

    /**
     * Load data from storage
     * @param {string} key 
     * @param {any} defaultValue - Returned if key doesn't exist
     */
    get(key, defaultValue = null) {
        const data = this._loadAll();
        return data[key] ?? defaultValue;
    }

    /**
     * Delete data from storage
     * @param {string} key 
     */
    delete(key) {
        const data = this._loadAll();
        delete data[key];
        world.setDynamicProperty(this.namespace, JSON.stringify(data));
    }

    /**
     * Check if key exists
     * @param {string} key 
     */
    has(key) {
        const data = this._loadAll();
        return key in data;
    }

    /**
     * Get all stored keys
     */
    keys() {
        const data = this._loadAll();
        return Object.keys(data);
    }

    /**
     * Clear all data in this namespace
     */
    clear() {
        world.setDynamicProperty(this.namespace, JSON.stringify({}));
    }

    // Private method to load all data
    _loadAll() {
        const raw = world.getDynamicProperty(this.namespace);
        return raw ? JSON.parse(raw) : {};
    }
}

// Global instance for quick access
const storage = new EasyStorage();

// Player-specific storage helper
class PlayerStorage {
    /**
     * @param {Player} player 
     * @param {string} namespace - Default: 'playerData'
     */
    constructor(player, namespace = 'playerData') {
        this.player = player;
        this.storage = new EasyStorage(namespace);
    }

    set(key, value) {
        this.storage.set(`${this.player.id}_${key}`, value);
    }

    get(key, defaultValue = null) {
        return this.storage.get(`${this.player.id}_${key}`, defaultValue);
    }

    delete(key) {
        this.storage.delete(`${this.player.id}_${key}`);
    }
}

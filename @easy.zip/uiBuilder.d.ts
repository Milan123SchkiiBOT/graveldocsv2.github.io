

declare namespace uiDB {

  const uis: {
    readonly testmeow: "testmeow";
    readonly lol: "lol";
    
  };
  
  const displayNames: {
    readonly [key in keyof typeof uis]?: string;
  };
}

declare namespace uiManager {

  function registerUIs(...entries: string[]): void;


  function registerBuilder(
    key: keyof typeof uiDB.uis,
    theme: string,
    builderFunc: (player: Player, ...args: any[]) => UI
  ): void;


  function open(player: Player, key: keyof typeof uiDB.uis, ...args: any[]): void;
}

declare interface Player {
  name: string;
  
}

declare class UI {
  constructor(type: string);

  setTitle(title: string): this;
  addHeader(text: string): this;
  addLabel(text: string): this;
  addButton(
    key: string,
    icon?: string,
    position?: "left" | "middle" | "right",
    alt?: boolean
  ): this;
  setAction(callback: (res: { canceled: boolean; selection?: number }) => void): this;

  show(player: Player): void;
}

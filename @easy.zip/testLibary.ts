import { ActionFormData } from "@minecraft/server-ui";

const uiDB = {
  uis: {},
  displayNames: {}
};

const uiManager = {
  builders: {},
  displayNames: {},

  registerUIs(...entries) {
    for (const entry of entries) {
      const [key, display] = entry.split("|").map(e => e.trim());
      if (!key || !display) continue;
      uiDB.uis[key] = key;
      this.displayNames[key] = display;
    }
  },

  registerBuilder(key, theme, builderFunc) {
    this.builders[key] = { theme, builderFunc };
  },

  open(player, key, ...args) {
    const builder = this.builders[key];
    if (!builder) return;

    const ui = builder.builderFunc(player, ...args);

    const form = new ActionFormData()
      .title(ui.title || "UI");

    
    const lines = ui.elements
      .filter(e => e.type === "header" || e.type === "label")
      .map(e => e.type === "header" ? `§l${e.text}` : e.text);
    form.body(lines.join("\n"));

    
    ui.elements.forEach(e => {
      if (e.type === "button") {
        const label = e.alt ? `[ALT] ${e.key}` : e.key;
        form.button(label, e.icon || undefined);
      }
    });

    form.show(player).then(res => {
      if (res.canceled) return;
      ui._action?.(res);
    });
  }
};

class UI {
  constructor() {
    this.title = "";
    this.elements = [];
  }

  setTitle(title) {
    this.title = title;
    return this;
  }

  addHeader(text) {
    this.elements.push({ type: "header", text });
    return this;
  }

  addLabel(text) {
    this.elements.push({ type: "label", text });
    return this;
  }

  addButton(text, icon = "") {
    this.elements.push({ type: "button", text, icon });
    return this;
  }

  setAction(player, callback) {
    const form = new ActionFormData().title(this.title);

    for (const el of this.elements) {
      if (el.type === "header") {
        form.header(el.text);  // <-- HIER wird native header() aufgerufen!
      } else if (el.type === "label") {
        form.body(el.text);
      } else if (el.type === "button") {
        form.button(el.text, el.icon);
      }
    }

    form.show(player).then(callback);
    return this;
  }
}


export { uiManager, UI, uiDB };
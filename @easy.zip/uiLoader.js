import { uiManager, uiDB } from "./testLibary.js";
// Dynamisch alle Dateien in ./uis laden (nur in echter Node.js Umgebung)
const modules = import.meta.glob("./uis/*.js", { eager: true });
for (const path in modules) {
    const { key, display, theme, builder } = modules[path].default;
    if (!key || !builder)
        continue;
    uiDB.uis[key] = key;
    uiManager.displayNames[key] = display || key;
    uiManager.registerBuilder(key, theme || "theme", builder);
}

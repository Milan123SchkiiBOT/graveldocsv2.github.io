const fs = require("fs");
const path = require("path");
const uiDir = path.resolve(__dirname, "uis");
const files = fs.readdirSync(uiDir).filter(f => f.endsWith(".js"));
const keys = [];
for (const file of files) {
    const mod = require(path.join(uiDir, file));
    // mod kann default export oder named export sein
    const ui = mod.default || mod;
    if (ui && ui.key) {
        keys.push(ui.key);
    }
}
const dtsContent = `
declare namespace uiDB {
  const uis: {
${keys.map(k => `    readonly ${k}: "${k}";`).join("\n")}
  };
}

declare namespace uiManager {
  function registerUIs(...entries: string[]): void;
  function registerBuilder(
    key: keyof typeof uiDB.uis,
    theme: string,
    builderFunc: (player: Player, ...args: any[]) => UI
  ): void;
  function open(player: Player, key: keyof typeof uiDB.uis, ...args: any[]): void;
}

declare interface Player {
  name: string;
}

declare class UI {
  constructor(type: string);
  setTitle(title: string): this;
  addHeader(text: string): this;
  addLabel(text: string): this;
  addButton(key: string, icon?: string, position?: "left"|"middle"|"right", alt?: boolean): this;
  setAction(callback: (res: { canceled: boolean; selection?: number }) => void): this;
  show(player: Player): void;
}
`;
fs.writeFileSync(path.resolve(__dirname, "uiBuilder.d.ts"), dtsContent.trim());
console.log("uiBuilder.d.ts generated with keys:", keys);
